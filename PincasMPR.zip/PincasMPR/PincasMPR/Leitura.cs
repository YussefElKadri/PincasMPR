﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PincasMPR
{
	internal class Leitura
	{
		public string Arquivos(string arquivos)
		{
			string pastaLeitura = Directory.GetCurrentDirectory();
			string[] arquivosMPR = Directory.GetFiles(pastaLeitura , "*.mpr" , SearchOption.AllDirectories);
			string arquivoTemporario = Path.GetTempFileName();
			DateTime dateTime= DateTime.Now;

			foreach (var mpr in arquivosMPR)
			{	
				string[] leituraLinhaMpr = File.ReadAllLines(mpr);
				StreamWriter escritaMPR = new StreamWriter(arquivoTemporario);
				{
					for (int i = 0; i < leituraLinhaMpr.Length; i++)
					{
						string leituraLinha = leituraLinhaMpr[i];

						if (!leituraLinha.Contains('!'))
						{
							if (leituraLinha.Contains("TNO=\"3\""))
							{
								escritaMPR.WriteLine(leituraLinha);
								escritaMPR.WriteLine("EN=\"0\"");
							}
							else if (leituraLinha.StartsWith("<101 \\Kommentar\\"))
							{

							}
							else
							{
								escritaMPR.WriteLine(leituraLinha);
							}
						}
						else
						{
							escritaMPR.WriteLine("<139 \\Komponente\\");
							escritaMPR.WriteLine("IN=\"ZP500.mpr\"");
							escritaMPR.WriteLine("XA=\"0.0\"");
							escritaMPR.WriteLine("YA=\"0.0\"");
							escritaMPR.WriteLine("ZA=\"0.0\"");
							escritaMPR.WriteLine("EM=\"0\"");
							escritaMPR.WriteLine("VA=\"X1 125\"");
							escritaMPR.WriteLine("VA=\"X2 c-125\"");
							escritaMPR.WriteLine("VA=\"Y1 70\"");
							escritaMPR.WriteLine("VA=\"F1 0\"");
							escritaMPR.WriteLine("VA=\"F2 0\"");
							escritaMPR.WriteLine("VA=\"F3 100\"");
							escritaMPR.WriteLine("VA=\"F4 100\"");
							escritaMPR.WriteLine("KAT=\"Komponentenmakro\"");
							escritaMPR.WriteLine("MNM=\"Component macro\"");
							escritaMPR.WriteLine("\n<101 \\Kommentar\\");
							escritaMPR.WriteLine("KM=\"Corrigido por PincasMPR - DMD Servicos\"");
							escritaMPR.WriteLine("KM=\"Contato: 43 9 9919 2981\"");
							escritaMPR.WriteLine("KM=\"Tipo da licenca: Licenca definitiva\"");
							escritaMPR.WriteLine("KM=\"" + dateTime + "\"");
							escritaMPR.WriteLine("!");
						}
					}
				}	
				escritaMPR.Close();
				escritaMPR.Dispose();

				File.Delete(mpr);
				File.Copy(arquivoTemporario, mpr);
			}
			return arquivos;
		}

	}
}
