﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Globalization;

namespace PincasMPR
{
	internal class Leitura
	{
		public decimal ComprimentoMPR { get; set; }
		public string Arquivos(string arquivos)
		{
			string pastaLeitura = Directory.GetCurrentDirectory(); // teste
			string[] arquivosMPR = Directory.GetFiles(pastaLeitura , "*.mpr" , SearchOption.AllDirectories);
			string arquivoTemporario = Path.GetTempFileName();
			DateTime dateTime= DateTime.Now;
			List<decimal> medidas= new List<decimal>();

			foreach (var mpr in arquivosMPR)
			{	
				string[] leituraLinhaMpr = File.ReadAllLines(mpr);

				StreamWriter escritaMPR = new StreamWriter(arquivoTemporario);
				{
					for (int i = 0; i < leituraLinhaMpr.Length; i++)
					{
						if (leituraLinhaMpr[i].StartsWith("_BSX=")) //Pega comprimento da peca
						{
							string numeroSemTitulo = leituraLinhaMpr[i].Replace("_BSX=", "");
							medidas.Add(Convert.ToDecimal(numeroSemTitulo));
							ComprimentoMPR = Convert.ToDecimal(numeroSemTitulo, CultureInfo.InvariantCulture);
						}

						if (!leituraLinhaMpr[i].Contains('!'))
						{
							if (leituraLinhaMpr[i].Contains("EM=\"MOD0\"") && leituraLinhaMpr[i + 9].Contains("KM=\"RANHURA-ESVAZIAMENTO\"")) //Coloca insercao serra embutida
							{
								escritaMPR.WriteLine("EM=\"MOD1\"");
							}
							else if (leituraLinhaMpr[i].Contains("TNO=\"3\"")) //Comenta fresa
							{
								escritaMPR.WriteLine("EM=\"MOD0\"");
								escritaMPR.WriteLine("EN=\"0\"");
							}
							else if (leituraLinhaMpr[i].StartsWith("<101 \\Kommentar\\")) //retira comentario
							{

							}
							else
							{
								escritaMPR.WriteLine(leituraLinhaMpr[i]); //Escreve linhas fora das regras de cima
							}
						}
						else
						{
							//Codigo da pinca
							escritaMPR.WriteLine("<139 \\Komponente\\");
							escritaMPR.WriteLine("IN=\"ZP500.mpr\"");
							escritaMPR.WriteLine("XA=\"0.0\"");
							escritaMPR.WriteLine("YA=\"0.0\"");
							escritaMPR.WriteLine("ZA=\"0.0\"");
							escritaMPR.WriteLine("EM=\"0\"");

							//Aplica medidas variaveis nas pincas
							
							if (ComprimentoMPR <= 300)
							{
								escritaMPR.WriteLine("VA=\"X1 c/2\"");
							}
							else if (ComprimentoMPR > 300 && ComprimentoMPR <=599)
							{
								escritaMPR.WriteLine("VA=\"X1 00\"");
							}
							else if (ComprimentoMPR > 599 && ComprimentoMPR <= 1199)
							{
								escritaMPR.WriteLine("VA=\"X1 125\"");
							}
							else
							{
								escritaMPR.WriteLine("VA=\"X1 300\"");
							}						
							
							if (ComprimentoMPR <= 300)
							{
								escritaMPR.WriteLine("VA=\"X2 _BSX-125\"");
							}
							else if (ComprimentoMPR > 300 && ComprimentoMPR <=599)
							{
								escritaMPR.WriteLine("VA=\"X2 _BSX-00\"");
							}
							else if (ComprimentoMPR > 300 && ComprimentoMPR <= 1199)
							{
								escritaMPR.WriteLine("VA=\"X2 _BSX-125\"");
							}
							else
							{
								escritaMPR.WriteLine("VA=\"X2 _BSX-300\"");
							}								

							escritaMPR.WriteLine("VA=\"Y1 70\"");
							escritaMPR.WriteLine("VA=\"F1 0\"");
							escritaMPR.WriteLine("VA=\"F2 0\"");
							escritaMPR.WriteLine("VA=\"F3 100\"");
							escritaMPR.WriteLine("VA=\"F4 100\"");
							escritaMPR.WriteLine("KAT=\"Komponentenmakro\"");
							escritaMPR.WriteLine("MNM=\"Component macro\"");
							escritaMPR.WriteLine("\n<101 \\Kommentar\\");
							escritaMPR.WriteLine("KM=\"Corrigido por PincasMPR - DMD Servicos\"");
							escritaMPR.WriteLine("KM=\"Contato: 43 9 9919 2981\"");
							escritaMPR.WriteLine("KM=\"Tipo da licenca: Licenca definitiva\"");
							escritaMPR.WriteLine("KM=\"" + dateTime + "\"");
							escritaMPR.WriteLine("KM=\"" + Path.GetFileName(mpr) + "\"");
							escritaMPR.WriteLine("!");
						}
					}
				}	
				escritaMPR.Close();
				escritaMPR.Dispose();

				File.Delete(mpr);
				File.Copy(arquivoTemporario, mpr);
			}
			return arquivos;
		}

	}
}
